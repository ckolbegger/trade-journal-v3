import AxeBuilder from '@axe-core/playwright';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { cpus, platform, release } from 'node:os';
import { test, expect } from '../browser/fixtures';
import { onboard, confirmPlan, fillPlan } from '../browser/helpers';
import { authority } from '../browser/d02-helpers';
const output = `implementation/evidence/bug-001/visual/${process.env.BUG001_EVIDENCE_RUN ?? Date.now()}`;
for (const width of [1440, 814, 390]) test(`reference board, modal keyboard and rejected draft journey at ${width}`, async ({ page, context, browserName, profilePath, playwright, baseURL }) => {
  await mkdir(output, { recursive: true }); await page.setViewportSize({ width, height: 900 });
  await page.clock.install({ time: new Date('2026-10-24T20:00:00Z') });
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  const geometry: Record<string, unknown> = {};
  async function capture(name: string) {
    await page.evaluate(() => document.fonts.ready);
    await page.screenshot({ path: `${output}/${width}-${name}.png`, fullPage: true });
    geometry[name] = await page.evaluate(() => ({ dpr: devicePixelRatio, width: innerWidth, scrollWidth: document.documentElement.scrollWidth, nav: document.querySelector('nav')?.getBoundingClientRect().toJSON() as unknown, main: document.querySelector('main')?.getBoundingClientRect().toJSON() as unknown, panel: document.querySelector('[role=dialog]')?.getBoundingClientRect().toJSON() as unknown, fonts: Array.from(document.fonts).map(font => ({ family: font.family, status: font.status })), focused: document.activeElement?.outerHTML }));
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    const axe = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    await writeFile(`${output}/${width}-${name}-axe.json`, JSON.stringify(axe)); expect(axe.violations).toEqual([]);
  }
  await page.goto('/'); await expect(page.getByLabel('Workspace time zone')).toBeVisible(); await capture('setup');
  // Onboard uses this same native profile; no root, readiness or coordinator substitution.
  await onboard(page); await capture('empty');
  await page.getByRole('button', { name: 'Workspace', exact: true }).click(); await capture('workspace');
  await page.getByRole('button', { name: 'New Plan', exact: true }).click(); await capture('plan-stage1-blank');
  await page.getByLabel('Stock symbol').fill('XYZ'); await capture('plan-stage1-filled'); await page.getByRole('button', { name: 'Next: Plan and reflection' }).click(); await capture('plan-stage2-blank'); await page.getByRole('button', { name: 'Confirm Plan' }).click(); await capture('plan-validation');
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await fillPlan(page); await capture('plan-stage2-filled'); await page.getByRole('button', { name: 'Confirm Plan' }).click(); await expect(page.getByRole('heading', { name: 'XYZ · Planned' })).toBeVisible(); await capture('planned-detail');
  await page.getByRole('button', { name: /Back to Trades/ }).click(); await expect(page.getByRole('button', { name: /XYZ · Planned/ })).toBeVisible(); await capture('planned-list');
  if (width === 1440) {
    expect(await page.getByRole('navigation').evaluate(nav => nav.getBoundingClientRect().width)).toBe(240);
    const row = await page.getByRole('button', { name: /XYZ · Planned/ }).boundingBox(); expect(row?.height).toBeGreaterThanOrEqual(66.5); expect(row?.height).toBeLessThanOrEqual(73.5);
    expect(await page.locator('main').evaluate(main => main.clientWidth - 48)).toBe(820);
  }
  await page.getByRole('button', { name: /XYZ · Planned/ }).click();
  await page.getByRole('button', { name: 'Record initial Position Change' }).click();
  const dialog = page.getByRole('dialog', { name: 'Opening entry' }); await capture('opening-blank');
  expect(await page.locator('[inert]').count()).toBe(1);
  if (width === 1440) expect((await dialog.boundingBox())?.width).toBe(440);
  await page.getByLabel('Execution 1 quantity (shares)').fill('100'); await page.getByLabel('Execution 1 price (USD)').fill('50');
  await page.getByRole('button', { name: 'Add another execution' }).click();
  const before = await authority(page);
  await page.getByRole('button', { name: 'Save opening entry' }).click();
  await expect(page.getByText('Nothing saved — Execution 2 needs a quantity and price')).toBeVisible(); expect(await authority(page)).toEqual(before);
  await page.getByRole('button', { name: 'Go to Execution 2 quantity' }).click(); await expect(page.getByLabel('Execution 2 quantity (shares)')).toBeFocused(); await capture('opening-rejected');
  await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(page.getByRole('button', { name: 'Continue unsaved entry' })).toBeFocused();
  await capture('draft-detail');
  await page.getByRole('button', { name: 'Continue unsaved entry' }).click(); await expect(page.getByLabel('Execution 1 quantity (shares)')).toHaveValue('100');
  await expect(page.getByText('Nothing saved — Execution 2 needs a quantity and price')).toBeVisible();
  await page.getByRole('button', { name: 'Remove draft row 2' }).click(); await expect(page.getByLabel('Execution 1 quantity (shares)')).toBeFocused();
  await page.getByLabel('Complete reflection now').check(); await page.getByLabel('As Planned', { exact: true }).check(); await page.getByLabel('Calm', { exact: true }).check(); await page.getByLabel('Decision confidence').selectOption('4'); await page.getByLabel('Note (optional)').fill('Synthetic retained reflection.');
  for (const liveWidth of [767, 768, 1023, 1024, 1440, 390, width]) {
    await page.setViewportSize({ width: liveWidth, height: 900 }); await page.getByLabel('Note (optional)').focus();
    await expect(page.getByLabel('Note (optional)')).toHaveValue('Synthetic retained reflection.');
    expect(await page.locator('nav').evaluate(nav => getComputedStyle(nav).position)).toBe(liveWidth < 1024 ? 'fixed' : 'static');
    await expect(dialog).toHaveCount(1);
    await expect.poll(async () => { const note = await page.getByLabel('Note (optional)').boundingBox(); const footer = await page.getByRole('button', { name: 'Save opening entry' }).boundingBox(); return !!note && !!footer && note.y >= 0 && note.y + note.height <= footer.y; }).toBe(true);
  }
  await page.getByRole('button', { name: 'Cancel', exact: true }).focus(); await page.keyboard.press('Tab'); await expect(page.getByRole('button', { name: 'Close opening entry' })).toBeFocused();
  await page.keyboard.press('Shift+Tab'); await expect(page.getByRole('button', { name: 'Cancel', exact: true })).toBeFocused();
  await expect.poll(async () => { const close = await page.getByRole('button', { name: 'Close opening entry' }).boundingBox(); return !!close && close.y >= 24 && close.y + close.height <= 900; }).toBe(true);
  await capture('opening-filled');
  await page.getByRole('button', { name: 'Save opening entry' }).click(); await expect(page.getByRole('heading', { name: 'XYZ · Open' })).toBeVisible(); await capture('open-detail'); await page.getByRole('button', { name: 'Trades', exact: true }).click(); await page.getByRole('button', { name: 'Open', exact: true }).click(); await capture('open-list'); await page.getByRole('button', { name: /XYZ · Open/ }).click();
  await page.getByRole('button', { name: 'View Trade Journal' }).click(); await capture('trade-journal'); await page.getByRole('button', { name: 'Close trade journal' }).click();
  await confirmPlan(page); await page.getByRole('button', { name: 'Record initial Position Change' }).click(); await page.getByLabel('Execution 1 quantity (shares)').fill('100'); await page.getByLabel('Execution 1 price (USD)').fill('50'); await page.getByRole('button', { name: 'Save opening entry' }).click();
  await page.getByRole('button', { name: 'Journal Debt', exact: true }).click(); await capture('debt-queue'); await page.getByRole('button', { name: 'Answer reflection', exact: true }).click(); await capture('owed-composer');
  await page.getByLabel('Decline owed reflection').check(); await page.getByRole('button', { name: 'Save Debt outcome' }).click(); await capture('debt-declined');
  const committed = await authority(page);
  await writeFile(`${output}/${width}-environment.json`, JSON.stringify({ browserName, browser: context.browser()?.version(), os: { platform: platform(), release: release(), cpu: cpus()[0]?.model }, profilePath, geometry, errors, inventory: JSON.parse(await readFile('dist/offline-inventory.json', 'utf8')) as unknown, before, committed }, null, 2)); expect(errors).toEqual([]);
  await context.close(); const offline = await playwright[browserName].launchPersistentContext(profilePath, { headless: true, baseURL, offline: true });
  try { const reopened = await offline.newPage(); await reopened.goto('/'); await expect(reopened.getByRole('heading', { name: 'Trades', exact: true })).toBeVisible(); expect(await authority(reopened)).toEqual(committed); } finally { await offline.close(); }
});
