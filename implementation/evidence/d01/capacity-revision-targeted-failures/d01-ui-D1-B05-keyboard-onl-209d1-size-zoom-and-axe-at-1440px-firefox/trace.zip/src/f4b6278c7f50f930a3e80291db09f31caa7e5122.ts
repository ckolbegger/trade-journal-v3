import AxeBuilder from '@axe-core/playwright';
import type { Locator, Page } from '@playwright/test';
import { test, expect } from './fixtures';
import { onboard, fillPlan, requireWritable } from './helpers';
async function tabTo(page: Page, target: Locator) {
  for (let i = 0; i < 50; i++) {
    if (await target.evaluate(element => element === document.activeElement)) return;
    // WebKit on macOS follows the host's text-only Tab preference; Option-Tab
    // traverses every native control without changing that system preference.
    await page.keyboard.press(page.context().browser()?.browserType().name() === 'webkit' ? 'Alt+Tab' : 'Tab');
  }
  throw new Error('Control not reachable through the keyboard');
}
test('D1-B02 invalid input, catalog conflict and Cancel preserve input and write no Plan', async ({ page, context }) => {
  await onboard(page); await fillPlan(page);
  await page.getByLabel('Stop (underlying price, USD)').fill('50');
  await page.getByRole('button', { name: 'Confirm Plan' }).click();
  await expect(page.getByRole('alert')).toContainText('Stop must be below intended entry so Planned risk is positive.');
  await page.getByLabel('Stop (underlying price, USD)').fill('45');
  const other = await context.newPage(); await other.goto('/');
  await other.getByRole('button', { name: 'Workspace', exact: true }).click();
  await other.getByLabel('Institution name').fill('Second brokerage');
  await other.getByRole('button', { name: 'Save Institution' }).click();
  await expect(other.getByLabel('Institution name')).toHaveValue('');
  await other.close();
  await page.getByRole('button', { name: 'Confirm Plan' }).click();
  await expect(page.getByRole('alert')).toContainText('Brokerage records changed in another tab.');
  await expect(page.getByLabel('Stock symbol')).toHaveValue('XYZ');
  await page.getByRole('button', { name: 'Review current references' }).click();
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await page.getByRole('button', { name: 'Trades', exact: true }).click();
  await expect(page.getByText('No confirmed Plans match this view.')).toBeVisible();
  await expect(page.getByRole('button', { name: /Execution|Backup|Restore|Report/ })).toHaveCount(0);
});
test('D1-B02 native transaction abort preserves every participant and entered Plan', async ({ page, context, playwright, browserName, profilePath, baseURL }) => {
  await onboard(page);
  const snapshot = () => page.evaluate(() => new Promise<unknown>((resolve, reject) => {
    const request = indexedDB.open('trade-journal-v3');
    request.onerror = () => reject(request.error ?? new Error('Open failed'));
    request.onsuccess = () => {
      const db = request.result; const transaction = db.transaction(['roots', 'versions', 'lifecycle']);
      const root = transaction.objectStore('roots').getAll(); const versions = transaction.objectStore('versions').getAll(); const lifecycle = transaction.objectStore('lifecycle').getAll();
      transaction.oncomplete = () => { resolve({ roots: root.result, versions: versions.result, lifecycle: lifecycle.result }); db.close(); };
      transaction.onerror = () => reject(transaction.error ?? new Error('Read failed'));
    };
  }));
  const before = await snapshot();
  await page.addInitScript(() => {
    const original = Object.getOwnPropertyDescriptor(IDBObjectStore.prototype, 'add')?.value as IDBObjectStore['add'];
    IDBObjectStore.prototype.add = function (value: unknown, key?: IDBValidKey) {
      if (this.name === 'versions' && typeof value === 'object' && value !== null && 'kind' in value && value.kind === 'JournalEntry') this.transaction.abort();
      return original.call(this, value, key);
    };
  });
  await page.reload(); await fillPlan(page);
  await page.getByRole('button', { name: 'Confirm Plan' }).click();
  await expect(page.getByRole('alert')).toContainText('Saving failed. Nothing was recorded.');
  await expect(page.getByLabel('Stock symbol')).toHaveValue('XYZ');
  await expect(page.getByText('Recovery Only', { exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Confirm Plan' })).toBeDisabled();
  expect(await snapshot()).toEqual(before);
  await context.close();
  const reopened = await playwright[browserName].launchPersistentContext(profilePath, { headless: true, baseURL });
  try {
    const recovered = await reopened.newPage(); await recovered.goto('/');
    await expect(recovered.getByText('No confirmed Plans match this view.')).toBeVisible();
    await fillPlan(recovered); await recovered.getByRole('button', { name: 'Confirm Plan' }).click();
    await expect(recovered.getByRole('heading', { name: 'XYZ · Planned' })).toBeVisible();
  } finally { await reopened.close(); }
});
for (const width of [390, 1440]) {
  test(`D1-B05 keyboard-only onboarding and Plan, live resize, zoom and axe at ${width}px`, async ({ page }, testInfo) => {
    await page.setViewportSize({ width, height: 900 });
    await requireWritable(page);
    await page.evaluate(() => { document.documentElement.style.zoom = '2'; });
    expect(await page.getByRole('heading').evaluate(heading => heading.scrollWidth <= heading.clientWidth)).toBe(true);
    await page.evaluate(() => { document.documentElement.style.zoom = ''; });
    await tabTo(page, page.getByLabel('Workspace time zone')); await page.keyboard.type('America/New_York');
    await tabTo(page, page.getByRole('button', { name: 'Create Workspace' })); await page.keyboard.press('Enter');
    await expect(page.getByLabel('Institution name')).toBeVisible();
    await tabTo(page, page.getByLabel('Institution name')); await page.keyboard.type('Fidelity');
    await tabTo(page, page.getByRole('button', { name: 'Save Institution' })); await page.keyboard.press('Enter');
    await expect(page.getByLabel('Account name')).toBeVisible();
    await tabTo(page, page.getByLabel('Account name')); await page.keyboard.type('Taxable');
    await tabTo(page, page.getByRole('button', { name: 'Save Account' })); await page.keyboard.press('Enter');
    await tabTo(page, page.getByRole('button', { name: 'New Plan' })); await page.keyboard.press('Enter');
    for (const [label, value] of [['Stock symbol', 'XYZ'], ['Quantity (shares)', '100'], ['Intended entry (USD)', '50'], ['Stop (underlying price, USD)', '45'], ['Target (underlying price, USD)', '60'], ['Why this trade, why now?', 'Improving earnings'], ['What would invalidate the thesis?', 'Thesis fails']]) { await tabTo(page, page.getByLabel(label)); await page.keyboard.type(value); }
    for (const liveWidth of [767, 768, width]) {
      await page.setViewportSize({ width: liveWidth, height: 900 });
      await expect(page.getByLabel('Stock symbol')).toHaveValue('XYZ');
      expect(await page.getByRole('navigation').evaluate(element => getComputedStyle(element).position)).toBe(liveWidth < 768 ? 'fixed' : 'static');
    }
    await page.evaluate(() => { document.documentElement.style.zoom = '2'; });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    for (const action of await page.getByRole('navigation').getByRole('button').all()) {
      const bounds = await action.boundingBox();
      expect(bounds).not.toBeNull();
      if (!bounds) throw new Error('Navigation action must be rendered');
      expect(bounds.x).toBeGreaterThanOrEqual(0);
      expect(bounds.x + bounds.width).toBeLessThanOrEqual(width);
      if (width < 768) {
        expect(bounds.y).toBeGreaterThanOrEqual(0);
        expect(bounds.y + bounds.height).toBeLessThanOrEqual(900);
      }
      expect(await action.evaluate(button => button.scrollWidth <= button.clientWidth)).toBe(true);
    }
    await page.screenshot({ path: testInfo.outputPath(`D1-zoom-${width}.png`), fullPage: true });
    await page.evaluate(() => { document.documentElement.style.zoom = ''; });
    const accessibility = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(accessibility.violations).toEqual([]);
    await tabTo(page, page.getByRole('button', { name: 'Confirm Plan' })); await page.keyboard.press('Enter');
    await expect(page.getByRole('heading', { name: 'XYZ · Planned' })).toBeVisible();
    await tabTo(page, page.getByText('View history', { exact: true })); await page.keyboard.press('Enter');
    await expect(page.getByText(/^Plan fact:/)).toBeVisible();
    await page.screenshot({ path: testInfo.outputPath(`D1-detail-${width}.png`), fullPage: true });
  });
}
